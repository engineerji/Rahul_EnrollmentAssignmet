package service;

import java.sql.Connection;

public interface DatabaseDao {

	public Connection getConnection();
}
